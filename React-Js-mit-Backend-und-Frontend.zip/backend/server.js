//
//Express wird benötigt, um verschiedene Server-Routen zu definieren. Server-Routen
const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());
//
const PortNummer = 8080;
//
const sqlite3 = require("sqlite3");
/////////////////////////////////////////////
// Hier verbinden wir unsere DatenBank mit //
/////////////////////////////////////////////
let db = new sqlite3.Database("./newdatenBank.db",(fehler) =>{
    if(fehler) console.error(fehler.message);
else
console.log
("Verbindung zum Datenbank newdatenBank.db erfolgreich aufgebaut :-)");
});
//////////////////////////////////////
const decodeText = (text) => {
  let ret = "",
    block = "";
  // *** //
  for (let p = 0; p < text.length; p++) {
    switch (text[p]) {
      case "X":
      case "L":
      case "G":
      case "H":
      case "J":
      case "P":
      case "F":
      case "E":
        ret += String.fromCharCode(Number(block));
        block = "";
        break;
      default:
        block += text[p];
        break;
    }
  }
  // *** //
  return ret;
};

//////////////////////////////////////
app.get("/abruf/produkt/tabelle", (req, res) => {
    db.all(`SELECT * FROM Produkte`, (fehler, zeilen) => {
     console.log(zeilen);
        res.send(JSON.stringify(zeilen));

    });
  });
////////////////////////////////
////////////////////////////////
app.get("/login/:u/:p", (req, res) => {
    db.all(
      `SELECT * FROM Verwaltung 
      WHERE EINTRAG1 = 'User' 
      AND EINTRAG2 = 'Passwort'
       AND WERT =
       '${req.params.u},${req.params.p}'`,
      (fehler, zeilen) => {
        res.send(zeilen.length > 0 ? "1" : "0");
      }
    );
});

/////////
app.get("/logout", (req, res) => {
    res.send("ok");
  });
//////////////
// Warenkorb
//////////////
//Add to DB
app.get("/warenkorb/neu/:d/:k", (req, res) => {
    const K = JSON.parse(req.params.k);
    const D = JSON.parse(req.params.d);
    console.log(K);
    console.log(D);
    db.run(
      `INSERT INTO Bestellungen
      (Details, Netto, MwSt,Brutto,Email)
       VALUES
    ('${req.params.d}', '${K.netto}', '${K.mwst}', '${K.brutto}', '${decodeText(K.email)}')`,
      (fehler) => (fehler) => console.error(fehler)
    );
    res.send({message: "ok"});
});

//Read All Orders
app.get('/warenkorb/lesen/all', (req,res)=>{
    const sql = `SELECT * FROM Bestellungen`;
    //
    db.all(sql, function(err,rows){
      console.log(rows);
      if(err) throw err;
      if(rows.length>0) res.send(rows);
    });
});
//Read User Orders
app.get('/warenkorb/lesen/:userEmail', (req,res)=>{
  const sql = `SELECT * FROM Bestellungen WHERE Email='${req.params.userEmail}'`;
  //
  db.all(sql, function(err,rows){
    if(err) throw err;
    if(rows.length>0) res.send(rows);
  });
});
app.get('/warenkorb/entf/:bNr',(req,res)=>{
  db.run(`DELETE FROM Bestellungen WHERE BestellNr= '${req.params.bNr}'`,
  (fehler)=> console.error(fehler));
  res.send("Bestellungen sind abgeschlossen..");
});
//
app.get("/abruf/datenschutz", (req, res) => {
    db.all(
      `SELECT * FROM Verwaltung WHERE EINTRAG1 = 'Datenschutz'`,
      (fehler, zeilen) => {
        res.send(JSON.stringify(zeilen));
      }
    );
  });
  //
  //::::::::::::::::::::::://
//
app.get("/abruf/impressum", (req, res) => {
    db.all(
      `SELECT * FROM Verwaltung WHERE EINTRAG1 = 'Impressum'`,
      (fehler, zeilen) => {
        res.send(JSON.stringify(zeilen));
      }
    );
  });
///////////////
app.get("/ablegen/kontakt/:objekt",(req,res)=>{
    const o = JSON.parse(req.params.objekt);
    db.run(
        `INSERT INTO KontaktAnfrage 
        (Vorname, Nachname, Telefon, Email, Nachricht)
        VALUES 
        ('${o.Vorname}',
        '${o.Nachname}',
        '${o.Telefon}',
        '${o.Email}',
        '${o.Nachricht}')`,
        (fehler) => console.error(fehler)
    );
});
////Lesen
app.get('/lesen/kontakt/all', (req,res) => {
  const sql = `SELECT * FROM KontaktAnfrage`;

  db.all(sql, function(error,rows){
    if(error) throw error;
    if(rows.length > 0) res.send(rows);
  });
});
///
app.get("/kontakt/entf", (req, res) => {
  db.run(
    `DELETE FROM KontaktAnfrage WHERE 
    KAID > '0'`,
    (fehler) => console.error(fehler)
  );
  res.send("OK");
});
//
app.get("/produkt/aendern/:name/:preis/:ProdID", (req, res) => {
    console.log(`UPDATE Produkte SET 
    Produktname = '${req.params.name}',
    Produktpreis = '${req.params.preis}' 
    WHERE ProdID = '${req.params.ProdID}'`);
    
    db.run(
      `UPDATE Produkte SET 
    Produktname = '${req.params.name}',
    ProduktPreis = '${req.params.preis}' 
    WHERE ProdID = '${req.params.ProdID}'`,
      (fehler) => console.error(fehler)
    );
    res.send("OK");
  });
  ///////
  app.get("/produkt/neu/:name/:preis", (req, res) => {
    db.run(
      `INSERT INTO Produkte
    ( Produktname, Produktpreis )
    VALUES
    (  
      '${req.params.name}',
      '${req.params.preis}')`,
      (fehler) => console.error(fehler)
    );
    res.send("OK");
  });
  //
  app.get("/produkt/entf/:ProdID", (req, res) => {
    db.run(
      `DELETE FROM Produkte WHERE ProdID = '${req.params.ProdID}'`,
      (fehler) => console.error(fehler)
    );
    res.send("OK");
  });
  //////////
  app.get("/artikelinfo/:arNr/:prod/:men/:preis", (req, res) => {
    db.all(
      `SELECT * FROM
    daten WHERE ArtikelNr ='${req.params.arNr}',
     Produkt = '${req.params.prod}',
    Menge = '${req.params.men}',
    AND Preis = '${req.params.preis}'`,
      (fehler, zeilen) => {
        res.send(JSON.stringify(zeilen));
      }
    );
  });
  //
  app.get("/artikel/auflisten/:ArNr",(req,res)=>{
    db.all(
        `SELECT * FROM daten WHERE ArtikelNr ='${req.params.ArNr}'`,(fehler,zeilen)=>{
            console.log(zeilen);
            res.send(JSON.stringify(zeilen));
        }
    );
  });
  //
  app.get("/artikel/:a1/:a2", (req, res) => {
    db.run(
      `INSERT INTO daten 
      ( Produkt, Menge)
      VALUES
      ( '${req.params.a1}', '${req.params.a2}' )`,
      (fehler) => console.error(fehler)
    );
    res.send("ok");
  });
  //
  app.get("/artikel/entf/:a1/:a2", (req, res) => {
    db.run(
      `DELETE FROM daten 
      WHERE Produkt = '${req.params.a1}' 
      AND Menge = '${req.params.a2}'`,
      (fehler) => console.error(fehler)
    );
    res.send("ok");
  });
  //:::::::://
  //
///////////
app.get("/abruf/socialmedia/:welche", (req, res) => {
    db.all(
      `SELECT * FROM Verwaltung WHERE EINTRAG1 = 'SocialMedia-${req.params.welche}'`,
      (fehler, zeilen) => {
        res.send(zeilen[0].WERT);
      }
    );
  });
  /////////////
  app.get("/socialMedia/aendern/:id/:wert", (req, res) => {
    const o = req.params;
    const e = o.id.toUpperCase();
    let sqlcode = "";
    //
    switch(e){
     case "T":
       sqlcode = `UPDATE Verwaltung SET WERT = '${o.wert}'
       WHERE EINTRAG1 = 'SocialMedia-${e}'`;
       break;
       //
       case "F":
       sqlcode = `UPDATE Verwaltung SET WERT = '${o.wert}'
       WHERE EINTRAG1 = 'SocialMedia-${e}'`;
       break;
       //
       case "I":
       sqlcode = `UPDATE Verwaltung SET WERT = '${o.wert}'
       WHERE EINTRAG1 = 'SocialMedia-${e}'`;
       break;
       //
       case "Y":
       sqlcode = `UPDATE Verwaltung SET WERT = '${o.wert}'
       WHERE EINTRAG1 = 'SocialMedia-${e}'`;
       break;
    }
    db.run(sqlcode,(fehler)=> console.error(fehler));
   res.send("OK");
   });
   //
  ///////////////////////////////
// Hier liegt die Server mit seinen PortNummer.
/////////////
  const server = app.listen(PortNummer,()=>{
    console.log(`Server horcht nach http://localhost:${PortNummer}/`);
  });



















