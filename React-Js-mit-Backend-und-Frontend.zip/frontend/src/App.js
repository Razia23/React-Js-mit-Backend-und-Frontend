
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Menu from "./Komponenten/Menu";
import Bestellung from "./Komponenten/Bestellung";
import Kontakt from "./Komponenten/Kontakt";
import Datenschutz from "./Komponenten/Datenschutz";
import Login from "./Komponenten/Login";
import SideBar from "./Komponenten/SideBar";
import Warenkorb from "./Komponenten/Warenkorb";
import Logout from "./Komponenten/Logout"
import Willkommen from "./Komponenten/Willkommen";
import Oops from "./Komponenten/Oops";
import UberUns from "./Komponenten/UberUns";
import Impressum from "./Komponenten/Impressum";
import Startseite from "./Komponenten/Startseite";
import Zugriff from "./Komponenten/Zugriff";
import WarenKorbElement from "./Komponenten/WarenKorbElement";
import ProduktFeld from "./Komponenten/ProduktFeld";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Menu />}>
          <Route path="/" element={<Startseite />} />
          <Route path="/Bestellung" element={<Bestellung />} />
          <Route path="/Datenschutz" element={<Datenschutz />} />
          <Route path="/Kontakt" element={<Kontakt />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Logout" element={<Logout />} />
          <Route path="/SideBar" element={<SideBar />} />
          <Route path="/Warenkorb" element={<Warenkorb />} />
          <Route path="/Willkommen" element={<Willkommen />} />
          <Route path="/Oops" element={<Oops />} />
          <Route path="/UberUns" element={<UberUns />} />
          <Route path="/Impressum" element={<Impressum />} />
          <Route path="/Zugriff" element={<Zugriff />} />
          <Route path="/WarenKorbElement" element={<WarenKorbElement />} />
          <Route path="/ProduktFeld" element={<ProduktFeld />} />
          
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
