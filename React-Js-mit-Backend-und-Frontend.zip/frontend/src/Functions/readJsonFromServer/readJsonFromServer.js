export default function readJsonFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als json weiterreichen
      .then((rohdaten) => rohdaten.json())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }