// die jeweiligen Unicode-Zahlen umwandelt und mit einem
// | Zeichen voneinander trennt.
 
export const encodeText = (text) => {
    let ret = "";
    let Seperator = ["X", "L", "G", "H", "J", "P", "F", "E"];
    let index = 0;
    // *** //
    for (let p = 0; p < text.length; p++) {
      ret += text[p].charCodeAt(0).toString() + Seperator[index];
      index++;
      if (index > Seperator.length - 1) index = 0;
    }
    // *** //
    return ret;
  };