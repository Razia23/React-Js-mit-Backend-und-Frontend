//
import SocialMedia from "./SocialMedia";
import "./styles.css";
import React, { useState, useEffect } from "react";
import readJsonFromServer from "../Functions/readJsonFromServer/readJsonFromServer";

//////////////////
// Kontakt Information als Inputfelder.
//////////////////
export default function Kontakt() {
  //::::::::://
  const [vorname, vornameUpdate] = useState("");
  const [nachname, nachnameUpadate] = useState("");
  const [email, emailUpdate] = useState("");
  const [telefon, telefonUpdate] = useState("");
  const [nachricht, nachrichtUpdate] = useState("");
  const [meineDaten, setMeineDaten] = useState([]);
  ////////////
  //
  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als text weiterreichen
      .then((rohdaten) => rohdaten.text())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }
  ////////////
  // Einen Button die Informationen Über schickt..
  //
  function senden() {
    const objekt = {
      Vorname: vorname.value,
      Nachname: nachname.value,
      Telefon: telefon.value,
      Email: email.value,
      Nachricht: nachricht.value,
    };
    //////////////////
    // Die Daten wurden von server schreiben
    //////////////////

    readTEXTFromServer(
      "http://localhost:8080/ablegen/kontakt/" + JSON.stringify(objekt),
      (antwort) => {
        vorname.value = "";
        nachname.value = "";
        telefon.value = "";
        email.value = "";
        nachricht.value = "";
      }
    );
  }
   //////////////////
    // Die Daten wurden von server lessen
    //////////////////
  useEffect(()=>{
    readJsonFromServer(`http://localhost:8080/lesen/kontakt/all`, (antwort) => {
      console.log(antwort);
      if(antwort.length > 0) {
        let myList = []
        antwort.forEach((zeile) => {
            myList.push(<li>{zeile.Vorname} {zeile.Nachname} {zeile.Email} {zeile.Telefon} {zeile.Nachricht}</li>);
        });
        setMeineDaten(myList);
      }
    })
  },[]);
  ///////////////////////
  //  den Löschbutton  //
  //////////////////////
  function loechen(){
    readTEXTFromServer("http://localhost:8080/kontakt/entf",
     (antwort)=>{
      setMeineDaten([]);
      alert("Die Dataien sind gelöscht..!")
    });
  }
  //////////////////
  // den Inhalt von Daten hier mit dem return ausgeben.
  ///////////////////
  return (
    <>
      <main
        style={{
          backgroundImage: "linear-gradient(to right,lightgray, silver, lightgray)",
          padding: "10px",
        }}
      >
        <div style={{ display: "grid", gridTemplateColumns: "50% 50%" }}>
          <div
            style={{
              marginLeft: "20%",
              width: "220px",
              backgroundImage: "linear-gradient(to right, gray,darkgray, lightgray,lightyellow,lightgray)",
              paddingLeft: "20px",
              marginTop: "3%",
              boxShadow: "0px 0px 8px black",
              paddingTop: "20px",
              paddingBottom: "20px",
              marginBottom: "3%",
              border:"2px darkgray groove",
            }}
          >
            <label> Vorname</label>
            <br />
            <input
              type="text"
              placeholder="Vorname"
              onKeyUp={(info) => vornameUpdate(info.target)}
            />
            <br />
            <label> Nachname </label>
            <br />
            <input
              type="text"
              placeholder="Nachname"
              onKeyUp={(info) => nachnameUpadate(info.target)}
            />
            <br />
            <label> E-Mail </label>
            <br />
            <input
              type="text"
              placeholder="Email"
              onKeyUp={(info) => emailUpdate(info.target)}
            />
            <br />
            <label> Telefon </label>
            <br />
            <input
              type="number"
              placeholder="Telefon"
              onKeyUp={(info) => telefonUpdate(info.target)}
            />
            <br />
            <label> Nachricht </label>
            <br />
            <textarea
              placeholder="Nachricht..."
              onKeyUp={(info) => nachrichtUpdate(info.target)}
            ></textarea>
            <br />
            <button style={{ marginLeft: "40%" }} onClick={() => senden()}>
              Senden
            </button>
          </div>
          <div
            style={{
              marginLeft: "20%",
              overflow: "auto",
              backgroundImage: "linear-gradient(to right, gray,darkgray, lightgray,lightyellow,lightgray)",
              paddingLeft: "20px",
              marginTop: "3%",
              boxShadow: "0px 0px 8px black",
              paddingTop: "20px",
              paddingBottom: "20px",
              marginBottom: "3%",
              border:"2px darkgray groove",
              borderRadius:"10px"
            }}
          >
            <h5>Ihre angegebene Dateien werden hier angezeigt...</h5>
            <p id="datei">
              <ol>
                {meineDaten}
              </ol>
            </p>
            <div>
            <button style={{backgroundColor:"black",color:"white"}}  onClick={()=>loechen()}>Löschen</button>
            </div>
           
          </div>
        </div>
        <SocialMedia />
      </main>
    </>
  );
}
