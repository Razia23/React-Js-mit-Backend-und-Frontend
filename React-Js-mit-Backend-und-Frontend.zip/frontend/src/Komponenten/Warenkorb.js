//
import { Outlet, Link } from "react-router-dom";
import "./styles.css";
import React, { useState, useEffect } from "react";
import WarenKorbElement from "./WarenKorbElement";
import readJsonFromServer from "../Functions/readJsonFromServer/readJsonFromServer";
import { encodeText } from "../Functions/encodeText/encodeText";

export default function Warenkorb() {
  //::::::::://
  //::::::://
  const [WarenkorbInhalt, WarenkorbInhaltUpdate] = useState([]);
  const [bestellung, bestellungUpdate] = useState({
    Gesamtnetto: 0,
    Mwst: 0,
    Endbetrag: 0,
  });
  //
  const [myEmail, setmyEmail] = useState({ email: "" });
  //
  function aktualisiertWarenkorb() {
    let WKJSON =
      sessionStorage.getItem("WKJSON") == null
        ? []
        : JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    let elemente = [];
    // *** //
    let ergeb = {
      Gesamtnetto: 0,
      Mwst: 0,
      Endbetrag: 0,
    };
    // *** //
    if (typeof WKJSON === "object" && WKJSON.length > 0) {
      WKJSON.forEach((zeile) => {
        let pgpNetto = 0;
        let pgpSteuer = 0;
        let pgpBrutto = 0;
        // *** //
        if (Number(zeile.Menge) !== 0 && Number(zeile.Preis)) {
          pgpBrutto = Number(zeile.Menge) * Number(zeile.Preis);
          //
          pgpSteuer = (pgpBrutto * 7) / 100;
          //
          pgpNetto = pgpBrutto - pgpSteuer;
        }
        // *** //
        ergeb.Gesamtnetto += pgpNetto;
        ergeb.Mwst += pgpSteuer;
        ergeb.Endbetrag += pgpBrutto;
        // *** //
        elemente.push(
          <>
            <WarenKorbElement Daten={zeile} Funk={aktualisiertWarenkorb} />
          </>
        );
      });
    }
    // *** //
    bestellungUpdate(ergeb);
    // *** //
    WarenkorbInhaltUpdate(elemente);
  }
  //
  useEffect(() => {
    aktualisiertWarenkorb();
  }, []);
  //
  function warenkorbLeeren() {
    sessionStorage.removeItem("WKJSON");
    aktualisiertWarenkorb();
  }
  //
  function kostenpflichtigBestellen() {
    ////////////
    let WKJSON2 = [];
    let sam =
      sessionStorage.getItem("WKJSON") === null ||
      sessionStorage.getItem("WKJSON") == ""
        ? []
        : JSON.parse(sessionStorage.getItem("WKJSON"));
    for (let s of sam) {
      if (s.Name !== "" && Number(s.Menge) >= 1) WKJSON2.push(s);
    }
    sessionStorage.setItem("WKJSON", JSON.stringify(WKJSON2));
    //
    console.log("kostenpflicht: ", WKJSON2);
    //
    let kosten = {
      netto: bestellung.Gesamtnetto,
      mwst: bestellung.Mwst,
      brutto: bestellung.Endbetrag,
      email: encodeText(myEmail.email),
    };

    console.log("Koseten E", kosten.email);

    readJsonFromServer(
      `http://localhost:8080/warenkorb/neu/${JSON.stringify(
        WKJSON2
      )}/${JSON.stringify(kosten)}`,
      (r) => {
        console.log(`----------DB: `, r);
      }
    );
    sessionStorage.removeItem("WKJSON");
    aktualisiertWarenkorb();
  }
  // *** //
  /*if(WKJSON.length > 0)
  {
    let kosten = {
      netto : bestellung.Gesamtnetto,
      mwst : bestellung.Mwst,
      brutto : bestellung.Endbetrag
    };
    // *** //
    kosten = JSON.stringify(kosten);*/
  // *** //
  // WKJSON = encodeText(JSON.stringify(WKJSON));//
  // *** //
  /*readTEXTFromServer(
      "http://localhost:8080/warenkorb/neu/" + 
      WKJSON + "/"+ kosten,
      (antwort) => {
        sessionStorage.removeItem("WKJSON");
        aktualisiertWarenkorb();
        
      }
      
    );*/
  function handleChanges(e) {
    setmyEmail({
      ...myEmail,
      [e.target.name]: e.target.value,
    });
    console.log(myEmail);
  }

  return (
    <>
      <h3>Warenkorb</h3>
      <div>
        <input
          type="text"
          name="email"
          placeholder="Your Email"
          onChange={(e) => {
            handleChanges(e);
          }}
        />
      </div>

      {WarenkorbInhalt}
      <hr />
      <p>Gesamtpreis: {bestellung.Gesamtnetto.toFixed(2)} €</p>
      <p>Steuer: {bestellung.Mwst.toFixed(2)} €</p>
      <p>Endbetrag: {bestellung.Endbetrag.toFixed(2)} €</p>
      <hr />
      <button onClick={() => warenkorbLeeren()}> Warenkorb leeren</button>
      <button onClick={() => kostenpflichtigBestellen()}>
        {" "}
        Kostenpflichtig bestellen
      </button>
      <footer
        style={{ textAlign: "right", marginRight: "10%", marginBottom: "3%" }}
      >
        <button style={{ backgroundColor: "silver" }}>
          <Link to="/Bestellung">Hier finden Sie Ihre Beschtellungen</Link>
        </button>
      </footer>
    </>
  );
}
