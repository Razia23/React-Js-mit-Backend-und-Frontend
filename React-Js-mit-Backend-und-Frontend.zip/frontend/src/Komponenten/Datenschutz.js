import "./styles.css";

/////////////////////
// Die Datenschutz Komponente ist hier.
////////////////////
export default function Datenschutz() {
  return (
    <>
      <div
        style={{
          backgroundImage: "url(daten4.webp)",
          backgroundPosition: "center center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="datenB" style={{ margin: "10px", padding: "10px", boxShadow:"0px 0px 4px black",borderRadius:"4px" }}>
          <h2 style={{ width: "100%", padding: "2px", textAlign: "center",textShadow:"0px 0px 2px black" }}>
            Datenschutz
          </h2>
          <h4>Datenschutz-hinweis</h4>
          <p>
            Datenschutz ist ein in der zweiten Hälfte des 20. Jahrhunderts
            entstandener Begriff, der teilweise unterschiedlich definiert und
            interpretiert wird. Je nach Betrachtungsweise wird Datenschutz als
            Schutz vor missbräuchlicher Datenverarbeitung, Schutz des Rechts auf
            informationelle Selbstbestimmung, Schutz des Persönlichkeitsrechts
            bei der Datenverarbeitung und auch Schutz der Privatsphäre
            verstanden. Datenschutz wird jedenfalls in Deutschland meist als
            Recht verstanden, dass jeder Mensch grundsätzlich selbst darüber
            entscheiden darf, wem wann welche „seiner“ persönlichen Daten
            zugänglich sein sollen.
            <hr />
            Der Wesenskern eines solchen Datenschutzrechts besteht dabei darin,
            dass die Machtungleichheit zwischen Organisationen und
            Einzelpersonen unter Bedingungen gestellt werden kann. Der
            Datenschutz soll der in der zunehmend digitalen und vernetzten
            Informationsgesellschaft bestehenden Tendenz zum sogenannten
            gläsernen Menschen, dem Ausufern staatlicher Überwachungsmaßnahmen
            (Überwachungsstaat) und der Entstehung von Datenmonopolen von
            Privatunternehmen entgegenwirken.
          </p>
          <p>
            Ja, grundsätzlich muss jeder Website-Betreiber eine
            Datenschutzerklärung haben. Diese Pflicht ergibt sich aus der DSGVO.
            Danach muss jeder, der personenbezogene Daten verarbeitet, die
            betroffenen Personen über die Einzelheiten der Verarbeitung
            aufklären. Bereits beim Aufrufen einer Website werden automatisch
            zumindest die IP-Adressen der Website-Besucher weitergeleitet oder
            gespeichert und damit verarbeitet. Da bereits IP-Adressen unter die
            personenbezogenen Daten zu fassen sind, trifft die Pflicht zur
            Datenschutzerklärung folglich jeden Website-Betreiber.
          </p>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              flexWrap: "wrap",
            }}
          >
            <img src="daten.jpg" alt="" />
            <img src="daten2.jpg" alt="" />
          </div>
          <hr />
          <p>
            Regelungsbedarf gibt es damit sowohl im Hinblick auf die
            Öffnungsklauseln der Datenschutz-Grundverordnung als auch wegen des
            Bedarfs der Bereinigung nationalen Datenschutzrechts. Diese Ziele
            sollen in Deutschland auf Bundesebene mit der Neufassung des
            Bundesdatenschutzgesetzes und der Änderung weiterer Gesetze erreicht
            werden.[5] Das Gesetz vom 30. Juni 2017[5] hebt nationales
            Datenschutzrecht auf oder überführt die bei Inkrafttreten der
            Datenschutz-Grundverordnung unwirksamen Regelungen des bisherigen
            Bundesdatenschutzgesetzes in andere Gesetzesbereiche, es passt
            Regelungen an und schafft teils neue Vorschriften für den
            Datenschutz. Bereits bei der Diskussion um die diversen
            Referentenentwürfe des Bundesinnenministeriums, das bei der
            Gesetzgebung federführend war, haben Datenschützer die unzureichende
            Berücksichtigung der Erfahrungen der letzten Jahre bemängelt.[6]
            Juristen bezweifeln die Vereinbarkeit des angepassten
            Bundesdatenschutzgesetzes mit europäischem Recht.
          </p>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              flexWrap: "wrap",
            }}
          >
            <img src="daten3.jpg" alt="" />
          </div>
          <footer style={{backgroundColor:"black",color:"white",padding:"15px",textShadow:"0px 0px 1px white"}}>
            <h5> USE CASES</h5>
            <h1> Get control of your unstructured data</h1>
            <p>
              Employees are creating, downloading, extracting, copying, and
              sharing data across an ever-growing digital ecosystem. As a
              result, the potential attack surface has expanded. The risks: data
              breach, data loss, and lasting reputational damage. 
              <br />
              Data Access Security helps organizations keep critical unstructured data safe.
            </p>
            <table>
              <tr>
                <th>Protect your organization from data breach and theft</th>
                <th>Automate essential data governance actions</th>
                <th>Optimize digital transformation</th>
              </tr>
              <tr>
                <td>
                  Understand your unstructured data risks. Prioritize the most
                  critical assets and lock them down.
                </td>
                <td>
                  Save time with automated data discovery, classification, and
                  integrated data access governance workflows
                </td>
                <td>
                  Get better visibility and enhanced security for critical
                  unstructured data assets before and after you migrate to the
                  cloud.
                </td>
              </tr>
            </table>
          </footer>
        </div>
      </div>
    </>
  );
}
