import React, { useState, useEffect } from "react";
import "./styles.css";
import Zugriff from "./Zugriff";

export default function Willkommen() {
  const [daten, datenLesen] = useState("");
  //
  // *** //


  return (
    <>
      {daten === "" || daten === 0 ? (

          <hr />
      ) : (
        <Zugriff />
      )}
      {daten === 0}
    </>
  );
}
