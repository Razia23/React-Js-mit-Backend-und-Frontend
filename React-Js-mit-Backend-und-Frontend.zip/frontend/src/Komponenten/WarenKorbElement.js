import React, { useState, useEffect } from "react";

export default function WarenKorbElement({ Daten, Funk }) {
  //::::::::::::::::::::::::::::::::::::::://
  //:: Meine WarenKorbElemente sind hier :://
  //::::::::::::::::::::::::::::::::::::::://
  const [kosten, kostenUpdate] = useState({});
  const [bild1, bild1New] = useState("");
  const [bild2, bild2New] = useState("");

  useEffect(() => {
    bild1New("public/" + Daten.ProduktBild1);
    bild2New("public/" + Daten.ProduktBild2);
    let p = Number(Daten.Preis);
    kostenUpdate({
      Typ: Daten.Typ,
      Name: Daten.Name,
      Menge: Daten.Menge,
      Preis: p.toFixed(2),
      Gesamt: (Number(Daten.Menge) * Number(Daten.Preis)).toFixed(2),
    });
    console.log(Daten);
  }, [Daten]);
  //::::::::::::::::::::::::::::::::://
  //:: Aktualisiren den WarenKorb ::://
  //:::::::::::::::::::::::::::::::://
  function warenKorbArrayAktualisieren() {
    let WKJSON =
      sessionStorage.getItem("WKJSON") == null
        ? []
        : JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    if (WKJSON.length > 0) {
      for (let p = 0; p < WKJSON.length; p++) {
        if (WKJSON[p].Typ === kosten.Typ && WKJSON[p].Name === kosten.Name) {
          WKJSON[p] = kosten;
          break;
        }
      }
    }
    // *** //
    sessionStorage.setItem("WKJSON", JSON.stringify(WKJSON));
    // *** //
    Funk();
  }
  //:::::::::::::::::::::::::://
  //:: Die neue Berechnung :://
  //::::::::::::::::::::::::://

  function neuBerechnen(menge) {
    let objekt = {
      Typ: kosten.Typ,
      Name: kosten.Name,
      Menge: menge,
      Preis: Number(kosten.Preis).toFixed(2),
      Gesamt: (menge * kosten.Preis).toFixed(2),
    };
    kostenUpdate(objekt);
    warenKorbArrayAktualisieren();
  }
  //::::::::::::::::::::::::::::://
  //:: Einen Button die Artikel :://
  //::::::    zu entfernen  ::::://
  //::::::::::::::::::::::::::::://
  function entfernen() {
    let WKJSON =
      sessionStorage.getItem("WKJSON") == null
        ? []
        : JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    let elemente = [];
    // *** //
    if (WKJSON.length > 0) {
      for (let p = 0; p < WKJSON.length; p++) {
        if (
          (WKJSON[p].Typ === kosten.Typ && WKJSON[p].Name !== kosten.Name) ||
          WKJSON[p].Typ !== kosten.Typ
        )
          elemente.push(WKJSON[p]);
      }
    }
    // *** //
    sessionStorage.setItem("WKJSON", JSON.stringify(elemente));
    // *** //
    Funk();
  }

  return (
    <table>
      <tbody>
        <tr>
          <td style={{ width: "20%" }}>
            {Daten.Typ === "A" || Daten.Typ === "object" ? (
              "Angebot"
            ) : (
              <img
                style={{
                  width: "80px",
                  height: "80px",
                }}
                src={Daten.ProduktBild1}
                alt={bild1}
              />
            )}
          </td>
          <td style={{ width: "20%" }}>{Daten.Name}</td>
          <td style={{ width: "12%" }}>{Daten.Preis} €</td>
          <td style={{ width: "12%" }}>
            <input
              type="number"
              defaultValue={Daten.Menge}
              onKeyUp={(e) => neuBerechnen(e.target.value)}
              onChange={(e) => neuBerechnen(e.target.value)}
              onMouseDown={(e) => neuBerechnen(e.target.value)}
              onMouseUp={(e) => neuBerechnen(e.target.value)}
            />
          </td>
          <td style={{ width: "16%" }}>{kosten.Gesamt} €</td>
          <td style={{ width: "20%" }}>
            <button onClick={() => entfernen()}>Entfernen</button>
          </td>
        </tr>
      </tbody>
    </table>
  );
}
