import "./styles.css";
import {React, useEffect} from "react";

//////////////////
// hier ist den Logout Komponente.
//////////////////
export default function Logout(){
    useEffect(
        ()=>{
            localStorage.setItem("eingeloggt", "0");
            window.setTimeout(
                ()=>{
                    window.location.href="http://localhost:3000/";
                },
                1000  
            );
        }
        ,[]
    );

    return(
        <>
        <div>
        <h3>Du bist ausgeloggt</h3>
        <p>Vielen Dank für deinen Besuch. Bis dann :-)</p>
        </div>
        </>
    );
}