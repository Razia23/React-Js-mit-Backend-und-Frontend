import { useEffect, useState } from "react";
import Login from "./Login";
import "./styles.css";

import Willkommen from "./Willkommen";

export default function Oops({ u, p }) {
  const [benutzer, benutzerAbruf] = useState(false);
  //
  function returnText(u, cb) {}
  //
  useEffect(() => {
    returnText(
      "http://localhost:8080/login" +"/"+ u + "/" + p,
      (antwort) => {
        if (antwort === "OK") {
          localStorage.setItem("eingeloggt", 1);
          benutzerAbruf(<Willkommen />);
        } else {
          localStorage.setItem("eingeloggt", 0);
          benutzerAbruf(<Login />);
        }
      }
    );
  }, []);
  return (
    <>
    <div>
      <h3>Oops, es ist was schiefgelaufen</h3>
      <p>Benutzername oder Kennwort falsch!!!</p>
      <hr />
      <>{benutzer}</>
      </div>
    </>
  );
}
