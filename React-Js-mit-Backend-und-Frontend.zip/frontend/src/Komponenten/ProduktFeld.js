import React, { useState, useEffect } from "react";

export default function ProduktFeld({ Daten, Funk }) {
  const [details, detailsUpdate] = useState({});
  const [bild1, bild1New] = useState("");
  const [bild2, bild2New] = useState("");
  const [menge, setMenge] = useState(0);
  let preisMenge = menge * details.Preis;

  ///////////
  function zwischenSpeichern() {
    let sammeln =
      sessionStorage.getItem("zwischenSpeicher") === "" ||
      sessionStorage.getItem("zwischenSpeicher") === null
        ? []
        : JSON.parse(sessionStorage.getItem("zwischenSpeicher"));

    // *** //
    let status = false;
    // *** //
    console.log("Sammeln: ", sammeln);
    for (let x = 0; x < sammeln.length; x++) {
      if (sammeln[x].ID === details.ID) {
        sammeln[x] = details;
        // *** //
        status = true;
        // *** //
        break;
      }
    }
    // *** //
    console.log("Sammeln Befor Push: ", sammeln);
    if (status === false) sammeln.push(details);
    console.log("Sammeln After Push: ", sammeln);
    // *** //
    sessionStorage.setItem("zwischenSpeicher", JSON.stringify(sammeln));
    // *** //
    Funk();
  }

  function ausKommaWirdPunkt(wert) {
    let t = "";
    // *** //
    if (typeof wert === "number") return wert;
    // *** //
    for (let x = 0; x < wert.length; x++) {
      switch (wert[x]) {
        case ",":
          t += ".";
          break;
        default:
          t += wert[x];
          break;
      }
    }
    // *** //
    return Number(t);
  }
  //Das Leutft nur einmal bei erste laden
  useEffect(() => {
    bild1New("public/" + Daten.ProduktBild1);
    bild2New("public/" + Daten.ProduktBild2);

    ////////////
    const o = {
      Name: Daten.Produktname,
      Menge: 0,
      Preis: ausKommaWirdPunkt(Daten.Produktpreis),
      ID: Daten.ProdID,
      ProduktBild1: Daten.ProduktBild1,
      ProduktBild2: Daten.ProduktBild2,
    };
    // *** //
    detailsUpdate(o);
    // *** //
    zwischenSpeichern();
    //
  }, [Daten]);

  function aendern(wert) {
    setMenge(wert);
    let v = Number(wert);

    // *** //
    if (typeof v === "number") {
      // const o = {
      //   Name: details.Name,
      //   Menge: v,
      //   Preis: details.Preis,
      //   ID: details.ID,
      // };
      // // *** //
      // detailsUpdate(o);
      details.Menge = v;
      // *** //
      zwischenSpeichern();
      //
      Funk();
    }
  }
  //
  // Mit dem Mehr Button addriere ich den Artikel
  //
  function mehr() {
    let v = Number(menge);
    // *** //
    if (typeof v === "number") {
      let newMenge = v + 1;
      // *** //
      // const o = {
      //   Name: details.Name,
      //   Menge: newMenge,
      //   Preis: details.Preis,
      //   ID: details.ID,
      // };
      details.Menge = newMenge;
      //
      // *** //
      // console.log(`KKKKKKK:`, o)
      //detailsUpdate(o);
      // *** //
      zwischenSpeichern();
      //
      setMenge(newMenge);
      //
      Funk();
      //END IF
    }
  }
  //
  // Mit dem Weniger Button redusiere ich den Artikel.
  //
  function weniger() {
    let v = menge;
    // *** //
    if (typeof v === "number") {
      if (v >= 0) {
        let newMenge = v - 1;
        details.Menge = newMenge;
        zwischenSpeichern();
        setMenge(newMenge);
        Funk();
      }
      if (v < 0) {
        details.Menge = 0;
        setMenge(0);
        zwischenSpeichern();
        Funk();
      }
    }
  }

  //
  return (
    <>
      <tr>
        <td>
          {bild1 === null ? (
            <></>
          ) : (
            <img
              style={{
                borderRadius: "50%",
                width: "80px",
                height: "80px",
              }}
              src={Daten.ProduktBild1}
              alt={bild1}
            />
          )}
        </td>
        <td>
          {bild2 === null ? (
            <></>
          ) : (
            <img
              style={{
                borderRadius: "50%",
                width: "80px",
                height: "80px",
              }}
              src={Daten.ProduktBild2}
              alt={bild2}
            />
          )}
        </td>
        <td>
          <p>
            <b>{details.Name}</b>
          </p>
        </td>
        <td>
          <input
            type="number"
            placeholder="Menge..."
            value={menge}
            onKeyUp={(e) => aendern(e.target.value)}
            onChange={(e) => aendern(e.target.value)}
            onMouseDown={(e) => aendern(e.target.value)}
            onMouseUp={(e) => aendern(e.target.value)}
            name="mengeInput"
          />
        </td>
        <td>
          <p>
            <u>{details.Preis} €</u>
          </p>
        </td>
        <td>
          <p>
            <u>{preisMenge.toFixed(2)} €</u>
          </p>
        </td>
        <td>
          <button
            style={{ margin: "10px", backgroundColor: "black", color: "white" }}
            onClick={() => mehr()}
          >
            +
          </button>
        </td>
        <td>
          <button
            style={{ margin: "10px", backgroundColor: "black", color: "white" }}
            onClick={() => weniger()}
          >
            -
          </button>
        </td>
      </tr>
    </>
  );
}
