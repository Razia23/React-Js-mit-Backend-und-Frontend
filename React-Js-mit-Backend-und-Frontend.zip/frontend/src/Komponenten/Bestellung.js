import React, { useState, useEffect } from "react";
import readJsonFromServer from "../Functions/readJsonFromServer/readJsonFromServer";
import "./styles.css";

//
// Einen Funktion für die Bestellung Info
//
function BestellungInfo({ Daten }) {
//
const BestellNr = Daten.BestellNr;
//
  const renderDetails = () => {
    if (!Daten.Details) return null;

    const detailObjekte = JSON.parse(Daten.Details);
    console.log(Daten);
    return detailObjekte.map((detail, index) => (
      <div style={{marginLeft:"10px"}} key={index}>
        <p><b>Name: {detail.Name}</b></p>
        {detail.ProduktBild1 ? <p><img
        style={{width:"100px", height:"100px",padding:"0px"}} src={"./" + detail.ProduktBild1} /></p>:""}
        <p>Menge: {detail.Menge}</p>
        <p>E-Mail:{Daten.Email}</p>
        <hr />
        <br />

      </div>
    ));
  };
  /////////////
  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als text weiterreichen
      .then((rohdaten) => rohdaten.text())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }
  //
  // Hier schliesse ich meine Bestellung
  //
function BestellungAbschliessen(){
  console.log(`was wird weitergeleitet ? : http://localhost:8080/warenkorb/entf/${BestellNr}`);

  readTEXTFromServer("http://localhost:8080/warenkorb/entf/"+ BestellNr,
  (antwort)=>{
    // Bei diesem Strukture zeige ich einen text mit
    //setTimeout in 5 Sekunde nachdem
    // ich den Artikel lösche.
 const fenster = document.createElement('p');
 fenster.classList.add("bestellungs");
 fenster.textContent = "Bestellung wurde abgeschlossen..!!";
 fenster.style.color = "red";
 document.body.appendChild(fenster);
 setTimeout(()=>{
  window.location.reload();
 },5000);
  
  });
}
  return (
    <tr style={{backgroundColor:"lightgray"}}>
      <td><p><b>{Daten.BestellNr}</b></p></td>
      <td>{renderDetails()}</td>
      <td><p><u>{Daten.Brutto.toFixed(2)} € </u></p></td>
      <td><button onClick={()=>BestellungAbschliessen()}>Bestellung-Abschließen</button></td>
    </tr>
  
  );
}

//////////////
// Ab hier fängt meine Komponente Bestellung
// da ich BestellungInfo als Inhalt benutze.
//////////////
export default function Bestellung() {
  const [inhalt, inhaltNeu] = useState([]);

  useEffect(() => {

    readJsonFromServer("http://localhost:8080/warenkorb/lesen/all", (antwort) => {
      const daten = antwort.map((zeile) => (
        <BestellungInfo key={zeile.BestellNr} Daten={zeile} />
      ));
      inhaltNeu(daten);
    });
  }, []);

  return (
    <>
      <table>
        <thead>
          <tr>
            <th>Bestellnummer</th>
            <th>Details</th>
            <th><u>Endpreis</u></th>
          </tr>
        </thead>
        <tbody>
          {inhalt}
        </tbody>
      </table>
    </>
  );
}
