import "./styles.css";
import React, { useState, useEffect } from "react";
import Oops from "./Oops";
import Willkommen from "./Willkommen";

/////////////////
// Bevor ich die Startseite erreiche,musste ich mich zuerst Einlogen
// so habe ich den login Struktur gebaut.
/////////////////
export default function Login() {
  const [benutzerName, benutzerNameUpdate] = useState("");
  const [benutzerPass, benutzerPassUpdate] = useState("");
  //
  const [anmelden, anmeldenUpdate] = useState("");
  //
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als JSON weiterreichen
      .then((rohdaten) => rohdaten.json())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }

  function anmeldung() {
    readJSONFromServer(
      "http://localhost:8080/login/" + benutzerName + "/" + benutzerPass,
      (antwort) => {
        console.log("Login", antwort);
        if (Number(antwort) == 1) {
          localStorage.setItem("eingeloggt", "1");
          
          anmeldenUpdate(true);
          window.location.href = "http://localhost:3000/";
        } else {
          localStorage.setItem("eingeloggt", "0");
          anmeldenUpdate(false);
        }
      }
    );
  }

  /*/// login/:name/:pass ///*/

  ///::::::::::///
  return (
    <>
      {anmelden === "" || anmelden === "0" || anmelden === false ? (
        <>
          <div
          style={{
            backgroundColor:"lightgray",
            margin:"10px",
            padding:"10px",
            textAlign:"center",
          }}
           className="einlogenkalsse">
            <h3>Einloggen</h3>
            <input
              type="text"
              placeholder="Benutzername"
              onKeyUp={(objekt) => benutzerNameUpdate(objekt.target.value)}
            />
            <br />
            <input
              type="text"
              placeholder="Kennwort..."
              onKeyUp={(objekt) => benutzerPassUpdate(objekt.target.value)}
            />
            <br />
            <button onClick={() => anmeldung()}>Jetzt Einloggen</button>
          </div>
        </>
      ) : (
        <Willkommen />
      )}
      {anmelden === false ? <Oops /> : <></>}
    </>
  );
}
