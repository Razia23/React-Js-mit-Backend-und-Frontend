import { Outlet, Link } from "react-router-dom";
import React, { useEffect, useState } from "react";
import "./styles.css";
import SideBar from "./SideBar";
import Login from "./Login";

////////////////////////////////////
// Die Menu von meine Hauptseite //
///////////////////////////////////
export default function Menu() {
  //
  const [status, statusNeu] = useState("");
  const [twitter, twitterNew] = useState("");
  const [facebook, facebookNew] = useState("");
  const [instagram, instagramNew] = useState("");
  const [youtube, youtubeNew] = useState("");
  /////////////////////////////////////////
  // in useEffect sind die linked von Internet seiten
  /////////////////////////////////////////
  useEffect(() => {
    let zustand = Number(localStorage.getItem("eingeloggt"));
    twitterNew("https://www.twitterperlen.de/");
    facebookNew("https://de-de.facebook.com/");
    instagramNew("https://www.instagram.com/");
    youtubeNew("https://www.youtube.com/watch?v=zM93yZ_8SvE");
    statusNeu(zustand);
  }, []);

  //

  return (
    <>
      {status != 1 ? (
        <>
          <Login />
        </>
      ) : (
        <>
          <header
            style={{
              display: "grid",
              gridTemplateColumns: "30% 40% 30%",
              color: "white",
              backgroundImage: "linear-gradient(gray,darkgray, lightgray,lightyellow,lightgray,gray)",
              margin: "4px",
              boxShadow: "0px 0px 10px black",
              borderRadius:"5px",
            }}
          >
            <div>
              <img className="logoAnimation" style={{
              borderRadius:"20px",margin:"5px",
              width:"160px",height:"70px",padding:"1px"}} src="logo2.webp" alt="" />
            </div>
            
            <div
              style={{
                marginTop:"10%",
                textAlign: "center",
                marginBottom: "4px",
              }}
            >
              <link
                rel="stylesheet"
                href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
              ></link>
              {/* <form class="example" action="action_page.php">
                
               
              </form> */}
              <input style={{width:"350px",borderRadius:"10px 0px 0px 10px"}} type="text" placeholder="Search.." name="search" />
              <button style={{borderRadius:" 0px 10px 10px 0px"}}type="submit">
                  <i className="fa fa-search"></i>
                </button>
            </div>
            <div>
              <SideBar
                z1={[
                  {
                    name: "Kontakt..",
                    funk: () => {
                      alert("Hallo");
                    },
                  },
                ]}
                s={{
                  bild: "phone.png",
                  p: "+491520001234",
                }}
                t={{
                  bild: "email.png",
                  text: "raz.rah@st.evb.de",
                }}
                x={{
                  bild: "location.png",
                  text: "Frankfurterstr. 22 F.a.m",
                }}
                y={{
                  Head1: "",
                  Head2: "",
                  Head3: "",
                  spalte1: "",
                  spalte2: "",
                  spalte3: "",
                }}
              />
            </div>
           
          </header>

          <main
            style={{
              backgroundImage: "url(hinter.jpg)",
              backgroundAttachment: "fixed",
              backgroundPosition: "center center",
              backgroundRepeat: "no-repeat",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                backgroundImage: "linear-gradient(black,gray, lightgray,lightyellow,gray)",
                color: "black",
                listStyleType: "none",
                textShadow: "0px 0px 1px black",
              }}
            >
              <ul>
                <li>
                  {" "}
                  <Link to="/">Start Seite</Link>
                </li>
                <li>
                  <Link to="/Kontakt">Kontakt</Link>
                </li>
                <li>
                  <Link to="/Warenkorb">Warenkorb</Link>
                </li>
                <li>
                  <Link to="/Logout">
                    <b>Abmelden</b>{" "}
                  </Link>
                </li>
              </ul>
            </div>
          </main>

          <Outlet />
          <footer
            style={{
              display: "grid",
              gridTemplateColumns:"50% 50%",
              color: "white",
              backgroundImage: "linear-gradient(gray,darkgray, lightgray,lightyellow,lightgray,gray)",
              margin: "3px",
              boxShadow: "0px 0px 8px black",
              borderRadius:"5px",
            }}
          >
            <div>
              <a href={twitter} target="_blank">
                <img src="twitter (2).png" alt="Twitter" />
              </a>

              <a href={facebook} target="_blank">
                <img src="facebook.png" alt="Facebook" />
              </a>

              <a href={instagram} target="_blank">
                <img src="instagram.png" alt="Instagram" />
              </a>
              <a href={youtube} target="_blank">
                <img src="youtube (2).png" alt="Youtube" />
              </a>
            </div>
            <div>
              <div>
                <ul>
                  <li>
                    <Link to="/Datenschutz">Datenschutz</Link>
                  </li>
                  <li>
                    <Link to="/UberUns">Über-Uns</Link>
                  </li>
                  <li>
                    <Link to="/Impressum">Impressum</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div style={{color:"darkgray", width:"100%",textAlign:"center",gridColumnEnd:"span 2"}}>
            <p>&copy copyright-Razia</p>
            </div>
          </footer>
          
        </>
      )}
    </>
  );
}
