import "./styles.css";
import React, { useState, useEffect } from "react";
import ProduktFeld from "./ProduktFeld";

export default function Startseite() {
  //::::::::://
  const [start, startUpdate] = useState([]);
  const [endeteBetrag, endetUpdate] = useState({
    Gesamtnetto: 0,
    Mwst: 0,
    Endbetrag: 0,
  });
  //
  //::::::://
  //
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als json weiterreichen
      .then((rohdaten) => rohdaten.json())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }
  //
  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server schicken
    window
      .fetch(u)
      // Antwort erhalten und als text weiterreichen
      .then((rohdaten) => rohdaten.text())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }
  //
  function aktualisieren() {
    let sammeln =
      sessionStorage.getItem("zwischenSpeicher") === "" ||
      sessionStorage.getItem("zwischenSpeicher") === null
        ? []
        : JSON.parse(sessionStorage.getItem("zwischenSpeicher"));
    // *** //
    let ges = 0;
    // *** //
    for (let eintrag of sammeln) {
      if (Number(eintrag.Menge) && Number(eintrag.Preis))
        ges += Number(eintrag.Menge) * Number(eintrag.Preis);
    }
    // *** //
    let steuerWert = (ges * 7) / 100;
    let nettoWert = ges - steuerWert;
    // *** //
    if (
      typeof ges === "number" &&
      typeof steuerWert === "number" &&
      typeof nettoWert === "number"
    ) {
      endetUpdate({
        Gesamtnetto: nettoWert.toFixed(2) === NaN ? 0 : nettoWert.toFixed(2),
        Mwst: steuerWert.toFixed(2) === NaN ? 0 : steuerWert.toFixed(2),
        Endbetrag: ges.toFixed(2) === NaN ? 0 : ges.toFixed(2),
      });
    }
  }
  //
  useEffect(() => {
    readJSONFromServer(
      "http://localhost:8080/abruf/produkt/tabelle",
      (antwort) => {
        const daten = [];
        //
        console.log("tabelle:", antwort);
        antwort.forEach((zeile) => {
          console.log(zeile);
          daten.push(
            <ProduktFeld
              Daten={zeile}
              Funk={() => aktualisieren()}
              key={zeile.Produktname}
            />
          );
        });
        //
        startUpdate(daten);
      }
    );
    //SessionStorage Lesen
  }, []);

  function zumWarenkorbHinzufuegen() {
    let WKJSON = [];

    let r =
      sessionStorage.getItem("zwischenSpeicher") == null ||
      sessionStorage.getItem("zwischenSpeicher") == ""
        ? []
        : JSON.parse(sessionStorage.getItem("zwischenSpeicher"));
    for (let e of r) {
      if (e.Name !== "" && Number(e.Menge) >= 1 && Number(e.Preis) !== 0)
        WKJSON.push(e);
    }
    sessionStorage.setItem("WKJSON", JSON.stringify(WKJSON));
    // *** //
    sessionStorage.removeItem("zwischenSpeicher");
    // *** //
    aktualisieren();
  }

  return (
    <>
      <div
        style={{
          backgroundImage: "url(hinter.jpg)",
          backgroundAttachment: "fixed",
          backgroundPosition: "center center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="startColor">
          <table
            style={{
              boxShadow: "0px 0px 2px black",
              borderRadius: "4px",
              textAlign: "center",
              padding: "20px",
              marginLeft: "10%",
            }}
          >
            <thead>
              <tr>
                <th></th>
                <th>Produktsname</th>
                <th>Menge</th>
                <th>Stückpreis</th>
                <th>Gesamtpreis</th>
              </tr>
            </thead>
            <tbody>
              {start}
              <tr>
                <td></td>
                <td style={{ color: "gray" }}>{endeteBetrag.Gesamtnetto} €</td>
                <td style={{ color: "gray" }}>{endeteBetrag.Mwst} €</td>
                <td style={{ color: "gray" }}>{endeteBetrag.Endbetrag} €</td>
              </tr>
            </tbody>
          </table>
          <div style={{ marginRight: "20px", textAlign: "right" }}>
            <button
              style={{
                margin: "10px",
                backgroundColor: "black",
                color: "white",
              }}
              onClick={() => zumWarenkorbHinzufuegen()}
            >
              Zum Warenkorb Hinzufügen
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
