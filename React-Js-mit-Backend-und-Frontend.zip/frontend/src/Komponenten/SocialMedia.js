//
import Startseite from "./Startseite";
import "./styles.css";
import React, { useState, useEffect } from "react";

export default function SocialMedia() {
  //::::::::::::::::::::::://
  //:: Die Social Medien :://
  //::::::::::::::::::::::://
  const [Status, StatusUpdate] = useState(false);
  const [stateVonT, stateVonTUpdate] = useState("");
  const [stateVonF, stateVonFUpdate] = useState("");
  const [stateVonI, stateVonIUpdate] = useState("");
  const [stateVonY, stateVonYUpdate] = useState("");

  useEffect(() => {
    let u = sessionStorage.getItem("Status");
    StatusUpdate(u === "1" ? true : false);
    // *** //
    textZumServer("http://localhost:8080/abruf/socialmedia/T", (antwort) =>
      stateVonTUpdate(antwort)
    );
    // *** //
    textZumServer("http://localhost:8080/abruf/socialmedia/F", (antwort) =>
      stateVonFUpdate(antwort)
    );
    // *** //
    textZumServer("http://localhost:8080/abruf/socialmedia/I", (antwort) =>
      stateVonIUpdate(antwort)
    );
    // *** //
    textZumServer("http://localhost:8080/abruf/socialmedia/Y", (antwort) =>
      stateVonYUpdate(antwort)
    );
  }, []);
  //
  //::::::::::::::::::::::://
  //
  const textZumServer = (adresse, funktion) => {
    window
      .fetch(adresse)
      .then((rohDaten) => rohDaten.text())
      .then((text) => funktion(text))
      .catch((fehler) => console.error(fehler));
  };
  //::::::::::::::::::::::::::::::::::::::::::::://
  //:: Die Social Medien kann ich hier ändern :://
  //:::::::::::::::::::::::::::::::::::::::::::://
  function socialMediaAktualisieren(welche) {
    let route = "";
    route =
      welche === "T"
        ? "http://localhost:8080/socialMedia/aendern/" + "T" + "/" + stateVonT
        : welche == "F"
        ? "http://localhost:8080/socialMedia/aendern/" + "F" + "/" + stateVonF
        : welche == "I"
        ? "http://localhost:8080/socialMedia/aendern/" + "I" + "/" + stateVonI
        : "http://localhost:8080/socialMedia/aendern/" + "Y" + "/" + stateVonY;

    // *** //
    if (route) textZumServer(route, (antwort) => {});
  }
  return (
    <>
      {Status === true ? (
        <Startseite />
      ) : (
        <>
          <input
            type="text"
            placeholder="T ..."
            defaultValue={stateVonT}
            onKeyUp={(ereignisObjekt) =>
              stateVonTUpdate(ereignisObjekt.target.value)
            }
          />
          <button onClick={() => socialMediaAktualisieren("T")}>
            Twitter Ändern
          </button>
          <hr />

          <input
            type="text"
            placeholder="Facebook ..."
            defaultValue={stateVonF}
            onKeyUp={(ereignisObjekt) =>
              stateVonFUpdate(ereignisObjekt.target.value)
            }
          />
          <button onClick={() => socialMediaAktualisieren("F")}>
            Facebook Ändern
          </button>
          <hr />

          <input
            type="text"
            placeholder="Instagram ..."
            defaultValue={stateVonI}
            onKeyUp={(ereignisObjekt) =>
              stateVonIUpdate(ereignisObjekt.target.value)
            }
          />
          <button onClick={() => socialMediaAktualisieren("I")}>
            Instagram Ändern
          </button>
          <hr />
          <input
            type="text"
            placeholder="Youtube ..."
            defaultValue={stateVonY}
            onKeyUp={(ereignisObjekt) =>
              stateVonYUpdate(ereignisObjekt.target.value)
            }
          />
          <button onClick={() => socialMediaAktualisieren("Y")}>
            Youtube Ändern
          </button>
        </>
      )}
    </>
  );
}
