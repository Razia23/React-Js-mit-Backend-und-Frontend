import React, { useState } from "react";
import "./Sidebar.css";

///////////////////////
// Den SideBar Funktion ist hier,
// mit Menu Auf und Zu funktionen.
///////////////////////
export default function SideBar({ s, t, x, y, z }) {
  const [sideBarStatus, sideBarAktion] = useState(false);

  const z1 = [];

  // *** //
  if (typeof z === "object" && z.length !== undefined && z.length > 0)
    z.forEach((eintrag) => {
      z1.push(<li onClick={eintrag.funk}>{eintrag.name}</li>);
    });

  const menuAufZu = () => {
    const bar = document.querySelector(".SideBar nav");
    // *** //
    switch (sideBarStatus) {
      case false:
        bar.classList.remove("sidebar-verstecken");
        bar.classList.add("sidebar-anzeigen");
        sideBarAktion(true);
        break;
      case true:
        bar.classList.add("sidebar-verstecken");
        bar.classList.remove("sidebar-anzeigen");
        sideBarAktion(false);
        break;
      default:
        break;
    }
  };

  return (
    <div className="SideBar">
      <div className="MenuButton" onClick={menuAufZu}>
        Menü
      </div>
      <nav className="sidebar-verstecken">
        <ul>{z1}</ul>
        <div className="SideBar-div1">
          <div>
            {typeof s === "object" ? <img src={s.bild} alt="" /> : <></>}
          </div>
          <div>{typeof s === "object" ? <p>{s.p}</p> : <></>}</div>
        </div>
        <div className="SideBar-div1">
          <div>
            {typeof t === "object" ? <img src={t.bild} alt="" /> : <></>}
          </div>
          <div>{typeof t === "object" ? <p>{t.text}</p> : <></>}</div>
        </div>
        <div className="SideBar-div1">
          <div>
            {typeof x === "object" ? <img src={x.bild} alt="" /> : <></>}
          </div>
          <div>{typeof x === "object" ? <p>{x.text}</p> : <></>}</div>
        </div>

        <div>
          {typeof y === "object" ? (
            <table>
              <tr>
                <th>{y.Head1}</th>
                <th>{y.Head2}</th>
                <th>{y.Head3}</th>
              </tr>
              <tr>
                <td>{y.spalte1}</td>
                <td>{y.spalte2}</td>
                <td>{y.spalte3}</td>
              </tr>
            </table>
          ) : (
            <></>
          )}
        </div>
      </nav>
    </div>
  );
}
