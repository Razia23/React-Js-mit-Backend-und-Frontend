import "./styles.css";
import React from "react";

export default function UberUns() {
  return (
    <>
      <div
        style={{
          padding: "0",
          backgroundImage: "url(hinter.jpg)",
          backgroundPosition: "center center",
          backgroundRepeat: "no-repeat",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="backgroundFarbe" style={{ padding: "20px" }}>
          <h3 style={{ width: "100%", padding: "2px", textAlign: "center" }}>
            Über-Uns
          </h3>
          <div
            style={{
            textAlign:"center",
              backgroundImage: "url(bild-kinder.jpg)",
              backgroundPosition: "center center",
              backgroundRepeat: "no-repeat",
              width: "85%",
              height: "260px",
              padding: "20px",
              margin: "40px",
            }}
          >
           <h3 style={{alignItems:"center",paddingTop:"13%"}}>Erste Schritte</h3> 
          </div>
    
          <h5>Die Welt von Kinder sind für uns wichtig.</h5>
          <p>
            Nur wenige von uns kennen noch den Wert der Natürlichkeit und lassen
            die Natur, wie sie ist. Kinder frisieren ihre Kätzchen und ziehen
            ihren Hündchen Hosen an, und die Männer sind bemüht, sich eine
            besondere Haltung zu erfinden, sich eine eigene Sprache und Schrift
            einzustudieren nur das Gekünstelte scheint noch Wert zu besitzen. In
            einem Dorf habe ich einmal einen Festzug beobachtet, in dem sogar
            die Maulesel mit bunten Bändern behängt waren. So unentbehrlich ist
            den Menschen die Verkleidung geworden, daß sie sogar ihre Pferde
            damit belästigen müssen.
          </p>
          <h5>.Wir bringen Sie am Ziel</h5>

          <p>
            Besonders viel Spaß macht Kleidung, wenn man sich verkleiden kann.
            Bringen Sie einen Koffer voller Kinderkleidung mit, meistens gibt es
            im Kindergarten ja einen Fundus mit frischer Kleidung. Mützen lassen
            Sie vorsichtshalber weg wegen Flohgefahr, alles andere ist ok,
            solange es regelmäßig gewaschen wird. Jedes Kind zieht reihum ein
            Kleidungsstück aus dem Koffer und so sind zum Schluss alle
            verkleidet. Sprechen Sie dabei viel, kommentieren und machen
            Komplimente. Die Adjektive groß und klein kann man dabei auch sehr
            gut wiederholen.
          </p>
          <h4>
            Kleid zeichnen schritt für schritt für anfänger & kinder - Zeichnen
            lernen
          </h4>
          <h5>Schritten</h5>
          <p>
            Sobald Kinder einen Stift o. ä. fassen und führen können, also
            ungefähr ab einem Lebensalter von einem Jahr, beginnt die
            Kritzelphase. Zunächst geht die Bewegung noch hauptsächlich vom
            Schultergelenk aus (sogenanntes Hiebkritzeln; ca. 12–16 Monate), was
            einzelne, wahllose Striche auf dem bekritzelten Untergrund
            hinterlässt, dann vom Ellenbogengelenk (Schwingkritzeln; ca. 16–22
            Monate), was zu dichten Strichlagen führt, die in beide Richtungen
            verlaufen (also etwa von links unten nach rechts oben und wieder
            zurück), dann vom Handgelenk. Damit ist das Kreiskritzeln möglich,
            das knäuelartige Spuren hinterlässt. Diese Phase ist mit ca. 21–23
            Monaten erreicht. Die Kinder sind jetzt auch in der Lage, den Stift
            anzuheben und dann wieder neu aufzusetzen, also voneinander
            getrennte Gebilde auf dem Untergrund zu hinterlassen. Etwa um das
            dritte Lebensjahr herum, wenn ein geschlossenes Kreisgebilde oder
            gerade Linien gezogen werden können, endet die Kritzelphase. Die
            Kinder beginnen jetzt mit ungefähr zweieinhalb Jahren, ihre
            Zeichnungen zu kommentieren und zu benennen. Erste
            Darstellungsabsichten lassen sich erkennen. Ab dem dritten
            Lebensjahr kommen auch noch die Zickzackkritzel und isolierte
            Kreiskritzel hinzu. Ein wichtiger Entwicklungsschritt ist es, die
            Gebärden zu verlangsamen. Wenn das Kind gewollt seine Malbewegungen
            verlangsamen kann, vermag es erste geometrische Formen, wie
            Halbkreise oder Kreise, abzubilden.
          </p>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              textAlign: "center",
              flexWrap: "wrap",
            }}
          >
            <img
              style={{
                width: "250px",
                height: "250px",
                padding: "2px",
                boxShadow: "0px 0px 5px black",
              }}
              src="mal-1.jpg"
              alt=""
            />
            <img
              style={{
                width: "250px",
                height: "250px",
                padding: "2px",
                boxShadow: "0px 0px 5px black",
              }}
              src="bild-pint.jpg"
              alt=""
            />
            <img
              style={{
                width: "250px",
                height: "250px",
                padding: "2px",
                boxShadow: "0px 0px 5px black",
              }}
              src="kleid.jpg"
              alt=""
            />
          </div>
          <h5>Kopffüßler</h5>
          <p>
            Kopffüßler Die ersten Gebilde auf Kinderzeichnungen, die für
            Erwachsene etwas Erkennbares darstellen, sind die sogenannten
            „Kopffüßler“. Sie bestehen zunächst aus einem Kreis mit fühler- oder
            tentakelartigen Gebilden, die nach allen Richtungen abstehen – dem
            sogenannten Tastkörper. Er hat zwar Ähnlichkeit mit
            Sonnendarstellungen auf späteren Kinderbildern, wird aber eher als
            Ausdruck der momentanen Entwicklungssituation des Kindes selbst, das
            nach allen Seiten hin Erfahrungen macht und seinen Horizont
            ausdehnt, angesehen. Später beschränkt sich die Anzahl an
            angehängten Gliedmaßen auf zwei bis vier und in den Kreis wird ein
            schematisches Gesicht eingefügt. Warum bei diesen frühen
            Menschendarstellungen regelmäßig der Rumpf fehlt, obwohl schon sehr
            viel jüngere Kinder wissen, dass es einen Bauch gibt, und diesen an
            sich selbst und anderen auch zeigen können, ist umstritten. Gegen
            Ende der Kopffüßlerphase, wenn sich auch die Strichmännchen
            entwickeln, werden auch andere Formen, etwa Rechtecke, in das
            Repertoire aufgenommen, so dass nun auch andere Bildinhalte als nur
            die „Urlebewesen“ dargestellt werden können.
          </p>
        </div>
      </div>
    </>
  );
}
