import "./styles.css";
import React from "react";

///////////////////
// Meine Impressum Seite.
///////////////////
export default function Impressum() {
  ///
  return (
    <>
      <div
        style={{
          backgroundColor: "lightgray",
          margin: "10px",
          padding: "10px",
          boxShadow:"0px 0px 4px black",borderRadius:"4px"
        }}
      >
        <h3 style={{textShadow:"0px 0px 2px black"}}>Impressum:</h3>
        <p>
          Ein Impressum (lateinisch impressum „Hineingedrücktes“ bzw.
          „Aufgedrücktes“) enthält die gesetzlich vorgeschriebene Angabe des
          oder der presserechtlich Verantwortlichen für einen im eigenen Namen
          veröffentlichten Text-, Wort- oder Bildbeitrag. Es muss den Verlag,
          den Autor, den Herausgeber oder die Redaktion benennen. Oft werden
          auch zusätzliche Informationen wie Druckerei, Erscheinungsweise,
          Erscheinungsjahr und Erscheinungsort aufgeführt. Je nach Art der
          Publikation und konkreter Gesetzeslage müssen oder mussten auch
          zusätzliche Angaben enthalten sein, beispielsweise zur steuerlichen
          Situation des Herausgebers oder eine erfolgte Prüfung durch die
          Zensur.
        </p>
        <p>
          Hierbei ist etwa die Einstellung von Meinungsäußerungen in Foren nicht
          kennzeichnungspflichtig. In diesen Fällen sei über den
          Plattformanbieter sichergestellt, dass die schutzwürdigen Belange der
          Beteiligten gewahrt werden können. Eine Kennzeichnungspflicht würde
          ansonsten dazu führen, dass die Kommunikation unterbliebe[3] ähnlich
          wie bei einem Klarnamenzszwang im Internet. Wie sich aus § 55 Abs. 1
          RStV ergibt, trifft einen Anbieter somit nur dann keine
          Impressumspflicht, und er kann seine Webseite völlig anonym ins
          Internet stellen, wenn sein Angebot ausschließlich persönlichen oder
          familiären Zwecken dient. Hierunter zählen insbesondere Inhalte, die
          passwortgeschützt sind und deren Passwort nur an Bekannte und
          Verwandte weitergegeben wird, Inhalte aus dem engsten persönlichen
          Lebensbereich, bei denen ein berechtigtes Interesse Dritter an der
          Identität des Websitebetreibers nicht existiert oder wenn der
          Erfassung der Webseite durch Suchmaschinen in Metatags oder in einer
          robots.txt-Datei widersprochen wird und der Inhalt dem persönlichen
          Bereich entstammt.[4] Am 7. November 2020 wurde der
          Rundfunkstaatsvertrag durch den Medienstaatsvertrag (MStV) abgelöst,
          der ähnliche Vorgaben zur Impressumspflicht enthält (§ 18 Abs. 2
          MStV):
        </p> 
        <br />
        <hr />
        <br />

        <p>
          Anbieter von Telemedien mit journalistisch-redaktionell gestalteten
          Angeboten, in denen insbesondere vollständig oder teilweise Inhalte
          periodischer Druckerzeugnisse in Text oder Bild wiedergegeben werden,
          haben zusätzlich zu den Angaben nach den §§ 5 und 6 des
          Telemediengesetzes einen Verantwortlichen mit Angabe des Namens und
          der Anschrift zu benennen. Werden mehrere Verantwortliche benannt, ist
          kenntlich zu machen, für welchen Teil des Dienstes der jeweils
          Benannte verantwortlich ist. Als Verantwortlicher darf nur benannt
          werden, wer
        <br />

          <ol>
            <li>seinen ständigen Aufenthalt im Inland hat,</li>
            <li>
              die Fähigkeit, öffentliche Ämter zu bekleiden, nicht durch
              Richterspruch verloren hat,
            </li>
            <li>unbeschränkt geschäftsfähig ist und</li>
            <li>unbeschränkt strafrechtlich verfolgt werden kann.</li>
          </ol>
        <br />

          Satz 3 Nr. 3 und 4 gilt nicht für Jugendliche, die Telemedien
          verantworten, die für Jugendliche bestimmt sind.
        <br />
        <br />
          
          <hr />
        </p>
        <h3>Grundsatzentscheidungen</h3>
        <p>
          Die Verlinkung und der Inhalt des Impressums war immer wieder
          Gegenstand von gerichtlichen Verfahren:
          <ol>
            <li>
              Das Oberlandesgericht Koblenz entschied am 25. April 2006 vor dem
              Hintergrund des Teledienstegesetzes, dass das Weglassen der
              zuständigen Aufsichtsbehörde keinen Verstoß darstellt, der nach
              dem Wettbewerbsrecht verfolgt werden könne, da es sich nach
              Ansicht des Gerichts um eine Bagatellverfehlung handele. Diese
              Entscheidung ist im Licht der UGP-Richtlinie 2005/29/EG allerdings
              nicht mehr haltbar: Art. 7 Abs. 5 der UGP-Richtlinie legt nämlich
              fest, dass eine Irreführung durch Unterlassen von Informationen
              immer dann vorliegen muss, wenn im Gemeinschaftsrecht festgelegte
              Informationsanforderungen in der Kommunikation nicht beachtet
              werden. Von dieser Regelung darf auch nicht in nationalem Recht
              abgewichen werden, da die Richtlinie Vollharmonisierung bezweckt.
              Die Regelung wurde daher Ende 2008 in § 5a Abs. 4 UWG umgesetzt.
              Die Pflicht zur Nennung der Aufsichtsbehörde in der
              Anbieterkennzeichnung ergibt sich wiederum aus der
              E-Commerce-Richtlinie 2000/31/EG. Für einen „Bagatellverstoß“ ist
              daher kein Raum mehr.
            </li>
            <br />

            <li>
              In einer Grundsatzentscheidung des Bundesgerichtshofs vom 20. Juli
              2006[7] wurde entschieden, dass es grundsätzlich ausreicht, wenn
              die Anbieterkennzeichnung über zwei Links (in diesem Fall:
              „Kontakt“ und „Impressum“) erreichbar ist.
            </li>
            <br />

            <li>
              Der Europäische Gerichtshof entschied mit Urteil vom 16. Oktober
              2008[8], dass eine Telefonnummer nicht zwingend im Impressum eines
              Telemediendienstes angegeben werden muss. Es sei allerdings eine
              zweite Kontaktmöglichkeit anzugeben, die es ermöglicht, „schnell
              mit dem Diensteanbieter Kontakt aufzunehmen und unmittelbar und
              effizient mit ihm zu kommunizieren“[9]. Eine „elektronische
              Anfragemaske“, über die innerhalb einer Stunde Anfragen
              beantwortet werden, erfülle diese Bedingung.
            </li>
            <br />
            <li>
              Mit seinem Urteil vom 15. Dezember 2010 entschied das Landgericht
              Düsseldorf, dass sogenannte „Baustellen-Seiten“ ebenfalls kein
              Impressum brauchen. In dem Fall bestand der Internetauftritt
              lediglich aus einer einzigen Seite mit einem Hinweis, dass die
              Internetseite überarbeitet werde, und verwies den Besucher darauf,
              die Internetseite später zu besuchen. Die Richter stellten fest,
              dass „der Internetauftritt zu diesem Zeitpunkt nicht den Zweck der
              Verfolgung wirtschaftlicher Interessen“ hatte und somit keine
              Impressumspflicht gemäß § 5 Abs. 1 TMG besteht.[10] Die
              Entscheidung des LG Düsseldorf begegnete dabei erheblichen
              Bedenken und es wurde Berufung eingelegt, die nach einem
              richterlichen Hinweis des Oberlandesgericht Düsseldorf
              zurückgenommen wurde. Dem gegenüber entschied das Landgericht
              Aschaffenburg im Urteil vom 3. April 2012 (AZ. 2 HK O 14/12), dass
              die Impressumspflicht auch für im Aufbau befindliche
              Internetseiten gilt, sofern der Internetauftritt bereits den Zweck
              hat, wirtschaftliche Interessen zu verfolgen.[11]
            </li>
          </ol><br />
          Als „sonstige Informationspflichten“ sind § 24 Abs. 4 und § 25 MedienG
          sowie § 14 Abs. 1 UGB (Unternehmensgesetzbuch) zu erwähnen. § 14 Abs.
          1 UGB bezieht sich neben Webseiten auch auf „alle Geschäftsbriefe und
          Bestellscheine, die auf Papier oder in sonstiger Weise an einen
          bestimmten Empfänger gerichtet sind“ und gilt daher insbesondere auch
          für E-Mails. Die Umsatzsteuer-Identifikationsnummer besteht aus einem
          Ländercode und 8 bis 12 Ziffern, z. B.: AT U 12345678. Sanktioniert
          wird die Missachtung der Impressumspflichten vom österreichischen
          Gesetzgeber als Verwaltungsübertretung, die mit einer Geldstrafe
          bedroht ist und von den Bezirksverwaltungsbehörden geahndet wird.
          Außerdem besteht die Gefahr, dass ein Mitbewerber einen
          Unterlassungsanspruch durchzusetzen versucht, etwa wenn der
          Diensteanbieter eine unvollständige Telefonnummer aufführt oder eine
          solche, die keinen Kontakt zum Diensteanbieter vermittelt. Außerdem
          besteht die Gefahr, dass bestimmte Verbraucherschutzverbände im Wege
          der sogenannten Verbandsklage einen Unterlassungsanspruch durchsetzen
          könnten.
        </p>
        <br />
      </div>
    </>
  );
}
