//
import React from "react";
import { Outlet, Link } from "react-router-dom";
import "./styles.css";

export default function Zugriff(){
//::::::::://

    return <>
    <h3>Zugriff zu diesem Bereich der Webseite ist für Besucher nicht gestattet.</h3>
    <hr />
    <Link to="/wechseln">Weiter zur Startseite…</Link>
    
    <Outlet />

    </>
};